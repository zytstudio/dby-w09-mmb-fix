#!/system/bin/sh
# Keep the KernelSU module description in sync with the runtime switch.
# The switch itself is read by libinputreader.so on every input event.
MODDIR=${0%/*}
DESC_ON="🟢 中键修复已开启：标准中键，不触发返回"
DESC_OFF="🔴 中键修复已关闭：中键变返回（华为原厂）"

update_desc() {
    if [ "$(getprop persist.mouse.middle_fix)" = "0" ]; then
        d="$DESC_OFF"
    else
        d="$DESC_ON"
    fi
    grep -qF "description=$d" "$MODDIR/module.prop" 2>/dev/null && return 0
    sed -i "s|^description=.*|description=$d|" "$MODDIR/module.prop" 2>/dev/null
}

while true; do
    update_desc
    sleep 15
done
