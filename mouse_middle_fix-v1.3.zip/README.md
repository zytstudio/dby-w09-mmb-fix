# Mouse Middle Button Fix (KernelSU module)

修复华为 Android 设备上**鼠标中键被系统全局映射为“返回”**的问题，让中键恢复为
Android 标准的 `BUTTON_TERTIARY`，可正常用于浏览器新标签页、应用内中键操作等。
与容器、GPU 等无关，纯输入层修复。

## 问题
华为的 `libinputreader.so` 把鼠标中键（`BTN_MIDDLE`）编码成 **Tertiary = 0x100**
（Android 标准是 `BUTTON_TERTIARY = 0x4`）。`CursorInputMapper` 随后检查 bit 8
（0x100），把它转成私有键码 `KEYCODE_BUTTON_MOUSE_SCROLL_WHEEL(747)`。
`system_server` 的 `MouseScrollWheelHandler` 收到 747 后注入 `KEYCODE_BACK`，
所以中键在系统全局都变成“返回”；同时 MotionEvent 带的是 0x100，应用也不认。

## 修复
对 `/system/lib64/libinputreader.so` 做两处修改：

1. `CursorButtonAccumulator::getButtonState` 中增加一个运行期分支（trampoline）：
   - 开关 ON：Tertiary 用 0x4（Android 标准 `BUTTON_TERTIARY`）
   - 开关 OFF：Tertiary 用 0x100（华为原厂行为，中键回到“返回”）
2. 分支读取系统属性：

       persist.mouse.middle_fix   (1 = ON, 0 = OFF, 默认 1)

`getButtonState` 每次被调用都会读取该属性，所以切换开关后**下一个输入事件**
立即生效，不需要重启系统或 system_server。属性是 `persist.`，重启后仍保留。

## 开关方式
KernelSU 管理器 → 模块 → `Mouse Middle Button Fix` → **执行/操作**
（Action 按钮），会运行模块里的 `action.sh`：

- 当前 ON → 切到 OFF，中键恢复为“返回”；
- 当前 OFF → 切到 ON，中键恢复为 Android 标准中键，不再触发返回。

也可以手动：

```sh
su -c 'setprop persist.mouse.middle_fix 1'   # ON
su -c 'setprop persist.mouse.middle_fix 0'   # OFF
```

## 状态显示
KernelSU 管理器里模块描述会自动显示当前状态：

- 🟢 中键修复已开启：标准中键，不触发返回
- 🔴 中键修复已关闭：中键变返回（华为原厂）

`action.sh` 切换后立即更新描述；`service.sh` 每 15 秒同步一次，手动
`setprop` 改开关也会在十几秒内跟上。如果管理器没有立刻刷新，下拉或重新
进入模块页面即可。

## 生效方式
`post-fs-data.sh` 在 zygote 启动前，用 `nsenter -t 1 -m -- mount --bind`
把本模块里的 `libinputreader_mmfix.so` 挂到 `/system/lib64/libinputreader.so`。
不修改 `/system` 或 `/vendor` 分区上的任何文件；卸载模块并重启即可恢复。

## 文件
- `libinputreader_mmfix.so`：带运行期开关的输入库（SHA-256 `a9b28248...`）
- `post-fs-data.sh`：开机早期 bind mount、原厂/补丁库哈希校验、初始化开关
- `action.sh`：KernelSU 模块 Action 按钮执行的开关脚本
- `service.sh`：每 15 秒同步描述状态
- `module.prop`：模块信息

## 原厂库校验
本补丁只适用于原厂库：

    82c3be7dd7a973b93887ecb4f2c8cea0b146b27c4ecce1aee7e684294c0ac5b6

系统 OTA 更新后哈希不匹配时会自动跳过挂载，不会用旧库覆盖新库。

## 验证
```sh
su -c 'cat /data/local/tmp/mouse_middle_fix.log'
su -c 'nsenter -t 1 -m -- grep inputreader /proc/self/mountinfo'
su -c 'sha256sum /system/lib64/libinputreader.so'   # a9b28248...
su -c 'getprop persist.mouse.middle_fix'            # 1 或 0
```

## 停用 / 卸载
```sh
su -c 'touch /data/adb/modules/mouse_middle_fix/disable'
su -c 'rm -rf /data/adb/modules/mouse_middle_fix'
# 然后重启
```
