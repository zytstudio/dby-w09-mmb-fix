#!/system/bin/sh
# Mount a patched libinputreader over the stock one before zygote starts.
#
# Huawei encodes the mouse middle button as tertiary state 0x100 and then
# CursorInputMapper turns bit 8 (0x100) into keycode 747, which system_server's
# MouseScrollWheelHandler converts into a global Back key.  The patch changes
# one instruction in CursorButtonAccumulator::getButtonState so tertiary is the
# Android standard BUTTON_TERTIARY (0x4) instead of 0x100.  The 747 branch no
# longer matches, and the MotionEvent carries a real middle button.
#
# Safety: only mount when the current /system/lib64/libinputreader.so is the
# exact stock build this patch was made for.  A system update changes the hash,
# so the module silently does nothing instead of replacing a newer library.
MODDIR=${0%/*}
SRC="$MODDIR/libinputreader_mmfix.so"
DST="/system/lib64/libinputreader.so"
LOG="/data/local/tmp/mouse_middle_fix.log"

DESC_ON="🟢 中键修复已开启：标准中键，不触发返回"
DESC_OFF="🔴 中键修复已关闭：中键变返回（华为原厂）"
update_desc() {
    if [ "$(getprop persist.mouse.middle_fix 2>/dev/null)" = "0" ]; then
        d="$DESC_OFF"
    else
        d="$DESC_ON"
    fi
    grep -qF "description=$d" "$MODDIR/module.prop" 2>/dev/null && return 0
    sed -i "s|^description=.*|description=$d|" "$MODDIR/module.prop" 2>/dev/null
}

STOCK_SHA256="82c3be7dd7a973b93887ecb4f2c8cea0b146b27c4ecce1aee7e684294c0ac5b6"
PATCHED_SHA256="a9b282487e494eecad6a4d5b8033e06900f99e33ac5703b87dd6a15d3a166626"

mkdir -p /data/local/tmp 2>/dev/null
exec >>"$LOG" 2>&1
echo "=== $(date) post-fs-data ==="

# Default the runtime switch to ON when unset.
if [ -z "$(getprop persist.mouse.middle_fix 2>/dev/null)" ]; then
    setprop persist.mouse.middle_fix 1
fi
update_desc

[ -f "$SRC" ] || { echo "missing $SRC"; exit 0; }
[ -f "$DST" ] || { echo "missing $DST"; exit 0; }

CUR=$(sha256sum "$DST" 2>/dev/null | awk '{print $1}')
if [ "$CUR" != "$STOCK_SHA256" ]; then
    echo "stock library hash mismatch ($CUR); skipping mount"
    exit 0
fi

PATCHED=$(sha256sum "$SRC" 2>/dev/null | awk '{print $1}')
if [ "$PATCHED" != "$PATCHED_SHA256" ]; then
    echo "patched library hash mismatch ($PATCHED); skipping mount"
    exit 0
fi

chcon u:object_r:system_lib_file:s0 "$SRC" 2>/dev/null

if /system/bin/nsenter -t 1 -m -- mount --bind "$SRC" "$DST"; then
    echo "bind ok (init ns)"
elif mount --bind "$SRC" "$DST"; then
    echo "bind ok (local ns)"
else
    echo "bind failed"
fi

/system/bin/nsenter -t 1 -m -- grep inputreader /proc/self/mountinfo | tail -1
exit 0
