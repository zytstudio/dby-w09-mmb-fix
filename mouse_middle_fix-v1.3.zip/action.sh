#!/system/bin/sh
# KernelSU module action: toggle the runtime middle-button switch and
# refresh the module description shown in the manager.
MODDIR=${0%/*}
DESC_ON="🟢 中键修复已开启：标准中键，不触发返回"
DESC_OFF="🔴 中键修复已关闭：中键变返回（华为原厂）"

update_desc() {
    if [ "$(getprop persist.mouse.middle_fix)" = "0" ]; then
        d="$DESC_OFF"
    else
        d="$DESC_ON"
    fi
    grep -qF "description=$d" "$MODDIR/module.prop" 2>/dev/null && return 0
    sed -i "s|^description=.*|description=$d|" "$MODDIR/module.prop" 2>/dev/null
}

CUR=$(getprop persist.mouse.middle_fix)
if [ "$CUR" = "0" ]; then
    setprop persist.mouse.middle_fix 1
    echo "Mouse middle fix: ON"
    echo "Middle button = Android BUTTON_TERTIARY (0x4), no Back key."
else
    setprop persist.mouse.middle_fix 0
    echo "Mouse middle fix: OFF"
    echo "Huawei original behavior: middle button = Back (tertiary 0x100)."
fi
update_desc
